# VigilX Frontend Integration Guide (V2)

The VigilX backend has completely transitioned from returning plain text chat replies to returning comprehensive **Investigation Reports**. 

To properly leverage this Enterprise AI architecture, we need to create a dedicated page in the frontend: **The AI Studio**.

---

## 1. The "AI Studio" Concept

Instead of a traditional ChatGPT-style interface, the **AI Studio** should behave like a live investigation dashboard.

**Layout Proposal:**
* **Left Sidebar (Chat/Command Line):** Where the officer types queries (e.g., "Find cases connected to FIR-2026-10005").
* **Main Center View (The Report):** When a response returns, this area populates with the `executive_summary`, `key_findings` (as cards or bullet lists), and `timeline` (rendered as a vertical interactive timeline).
* **Right Panel (Evidence & Analytics):** Displays the raw `evidence_bundle`, `related_entities` (graph networks), and renders any `chart_specs` (like Bar charts or Networks) sent by the backend.

---

## 2. API Call Structure

The frontend will communicate with the new V2 Orchestration Endpoint.

**Endpoint:** `POST /ai/v2/ask`  
*(Or via the Django REST proxy if configured)*

**Request Payload (`AskRequest`):**
```json
{
  "user_id": "officer_123",
  "session_id": "session_999",
  "question": "What is the sequence of events and timeline for FIR-2026-10150?"
}
```

---

## 3. The `InvestigationReport` JSON Format

When the backend finishes processing the query through the 17-agent LangGraph pipeline, it will return this structured JSON. The frontend should parse this object to render the AI Studio UI components.

```json
{
  "response_id": "uuid-string",
  "session_id": "session_999",
  "user_id": "officer_123",
  "intent": "timeline_query",
  "complexity": "multi_hop",
  
  "executive_summary": "The LLM's high-level summary of the investigation goes here. This is the only plain text paragraph.",
  
  "key_findings": [
    {
      "finding": "The suspect Rajesh was seen near the bank.",
      "evidence_ids": ["sql_rec_4", "neo4j_node_92"],
      "confidence": 0.92,
      "supported": true
    }
  ],
  
  "timeline": [
    {
      "timestamp": "2026-07-20T14:30:00Z",
      "event": "Robbery occurred at Connaught Place.",
      "source": "FIR-2026-10150",
      "confidence": 0.99,
      "citation_id": "cit_1"
    }
  ],
  
  "related_entities": [
    {
      "entity_type": "person",
      "name": "Ramesh Kumar",
      "role": "Accused",
      "relationship_to_case": "ACCUSED_IN",
      "confidence": 0.85
    }
  ],
  
  "evidence_bundle": {
    "sql_data": [...],
    "graph_data": [...],
    "vector_data": [...],
    "python_data": [...]
  },
  
  "citations": [
    {
      "source": "PostgreSQL:CaseMaster",
      "snippet": "Incident of robbery reported..."
    }
  ],
  
  "recommendations": [
    "Pull CCTV footage for the bank intersection.",
    "Interrogate co-accused Ramesh Kumar."
  ],
  
  "chart_specs": [
    {
      "type": "network",
      "data": {...},
      "title": "Criminal Network for FIR-2026-10150"
    }
  ],
  
  "confidence": 0.95,
  "confidence_label": "very_high",
  
  "clarification_needed": false,
  "clarification_question": null,
  
  "critic_passed": true,
  "critic_warnings": [],
  
  "metadata": {},
  "v2": true
}
```

### Key Frontend Implementation Notes
1. **Never render text if `critic_passed` is false.** Show the `critic_warnings` to the user instead.
2. **If `clarification_needed` is true,** pause the rendering of reports and display the `clarification_question` to the officer in the chat sidebar.
3. **Evidence Mapping:** Use the `evidence_ids` in `key_findings` to create clickable links that highlight the raw row in the `evidence_bundle` panel.
