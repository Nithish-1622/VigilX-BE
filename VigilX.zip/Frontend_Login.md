# Frontend Authentication Integration Guide (Zoho Catalyst)

The backend has been completely migrated away from custom JWTs. All authentication is now handled natively by Zoho Catalyst.

## Objective
Implement native Zoho Catalyst Authentication in the React/Next.js frontend to allow users to sign up, log in, and manage their sessions securely using the `zcatalyst-web` SDK.

## Requirements

### 1. Install Catalyst Web SDK
```bash
npm install zcatalyst-web
```

### 2. Initialize Catalyst in Frontend
You must initialize the SDK at the entry point of your application (e.g., `App.js` or `main.jsx`):
```javascript
import catalyst from 'zcatalyst-web';

catalyst.init({
    project_ID: "YOUR_PROJECT_ID", // Fetch this from Catalyst Console -> Environments
    environment: "Development" // Or Production
});
```
*Note: Ensure `project_ID` is stored in `.env.local` as `VITE_CATALYST_PROJECT_ID`.*

### 3. Implement Login & Signup
Do NOT make standard `axios` POST requests to our backend for authentication. Instead, use the Catalyst Auth module directly.

Catalyst provides a managed iframe widget for Login/Signup, or you can build a custom UI.
To build a custom UI, use the auth methods:
```javascript
// Sign Up
const signupConfig = {
    platform_type: 'web',
    redirect_url: 'https://vigilx.onslate.in/dashboard'
};
catalyst.auth.signUp(email, password, firstName, lastName, signupConfig);
```

### 4. Fetching Current User
To check if a user is logged in (to protect frontend routes):
```javascript
try {
    const user = await catalyst.auth.isUserAuthenticated();
    console.log("Logged in user:", user);
} catch (error) {
    console.log("Not logged in");
}
```

### 5. API Requests to Backend
Once authenticated, the Catalyst SDK automatically manages the `zcsession` cookie in the browser. 
When making `axios` requests to our backend API (`https://vigilx.development.catalystappsail.in/api/...`), you MUST set `withCredentials: true` so the browser includes the session cookie. Our Django backend will automatically read this cookie, validate it with Zoho, and log the user in instantly!

```javascript
import axios from 'axios';

const api = axios.create({
    baseURL: import.meta.env.VITE_API_BASE_URL,
    withCredentials: true // CRITICAL: This allows the Catalyst Session Cookie to be sent
});
```

## Summary for Frontend Agent
1. Delete any old custom JWT parsing/storage logic (no more `localStorage.getItem('token')`).
2. Use `zcatalyst-web` for login, signup, and logout.
3. Configure `axios` with `withCredentials: true`.
4. Protect routes using `catalyst.auth.isUserAuthenticated()`.
