# VigilX Built So Far

VigilX is an advanced AI-powered investigation platform that synthesizes criminal records, graph relationships, and semantic case facts into intelligent insights for law enforcement. 

This document outlines the massive architectural overhaul completed in **V2**.

---

## 1. The V2 AI Engine (LangGraph Orchestration)
The core intelligence layer (FastAPI) was completely rewritten. Instead of standard sequential LLM chains, VigilX V2 now utilizes a **LangGraph StateGraph** consisting of a 20-agent pipeline. 

### Key Agents in the Pipeline:
* **`IntentClassificationAgent`**: Analyzes the user's query and routes it to the specific database agents needed (e.g., suspect lookup, timeline, fuzzy search).
* **`PostgreSQLAgent` (Relational)**: Dynamically constructs and executes SQL to pull hard facts (Dates, Names, Statuses) from the Neon database.
* **`Neo4jAgent` (Graph)**: Traverses the criminal network to find hidden connections (e.g., `(Person)-[:ACCUSED_IN]->(Case)`).
* **`QdrantAgent` (Vector/Semantic)**: Performs similarity search across unstructured `BriefFacts` to find semantically related cases (e.g., "cyber fraud in Bengaluru").
* **`SynthesisAgent`**: Collates raw evidence from all database agents into a cohesive, highly readable summary.
* **`ResponseCriticAgent`**: A dedicated hallucination guardrail that verifies the `SynthesisAgent`'s output strictly matches the retrieved evidence, ensuring the LLM never invents data.

### Standardized V2 API Contract
The `/ai/v2/ask` endpoint now strictly outputs structured JSON matching the frontend requirements:
```json
{
  "intent": "suspect_query",
  "evidence_bundle": {
    "sql_data": [...],
    "graph_data": [...],
    "vector_data": [...]
  },
  "key_findings": ["Finding 1", "Finding 2"],
  "synthesis": "Final unified answer...",
  "confidence_score": 0.95
}
```

---

## 2. Infrastructure & Bulk Mock Data Seeding
To properly stress-test the multi-database reasoning engine, we generated a massive dataset.

* **The `bulk_seeder.py` Script**: A highly optimized Python script that generates massive amounts of mock Indian criminal data.
  * Uses `Faker` for realistic locales and names.
  * Uses `psycopg2.extras.execute_values` for high-speed Postgres bulk inserts.
  * Uses Neo4j `UNWIND` cypher queries for batch graph creation.
  * Uses `fastembed` locally to generate 384-dimension vector embeddings for Qdrant.
* **Current DB State**: Successfully seeded **5,000 rich FIR records** (along with 5,000 complainants and ~10,000 accused persons) across all 3 databases.

---

## 3. Testing & Development Tooling
* **Auth Bypass (`DEV_MODE`)**: We injected a `DevModeBypassAuthentication` middleware into Django. When `DEV_MODE=TRUE` in the `.env` file, the backend completely bypasses JWT token validation, allowing seamless API testing via Postman or automated scripts.
* **`test_v2_pipeline.py`**: A dedicated integration test script that hits the V2 AI Engine with 10 complex queries (e.g., graph lookups, multi-hop searches, fuzzy semantic matches). 
  * *Current Status: Passing with a 100% success rate on HTTP 200 and a 90% evidence retrieval hit rate on the mock data.*

---

## What's Next? (Frontend V2 Integration)
The backend V2 engine is feature-complete and successfully retrieving complex multi-database insights. The next major phase is updating the React/Next.js frontend interface to:
1. Parse the new JSON structure.
2. Display the `key_findings` and `evidence_bundle` in rich expandable UI components.
3. Add a dropdown to let the user toggle between the legacy V1 and the new V2 Orchestration engines.
