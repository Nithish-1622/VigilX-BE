# VigilX: Frontend Implementation & Integration Guide

This document outlines the detailed architecture, UI/UX guidelines, component structure, and API integration for the VigilX frontend. The frontend is built from scratch using **React + Vite + Tailwind CSS** in **JavaScript**.

---

## 1. Core Idea of the Project

**VigilX** is a next-generation, Multi-Agent AI Platform designed for advanced law enforcement, investigative analytics, and predictive policing. It transforms raw, siloed data from various databases (SQL, NoSQL, Graph, Vector) into actionable intelligence. 

By leveraging a decentralized architecture of specialized AI agents, VigilX can ingest crime reports, map out criminal syndicates, visualize data geographically and relationally, and allow officers to "chat with their data" to uncover deep, non-obvious insights. 

---

## 2. Tech Stack & Setup

*   **Framework:** React 18+ powered by Vite (for rapid HMR and optimized builds)
*   **Language:** JavaScript (ES6+)
*   **Styling:** Tailwind CSS (Utility-first CSS) + Custom CSS for complex animations
*   **Routing:** React Router v6
*   **State Management:** Zustand or Redux Toolkit
*   **Visualizations:**
    *   **Charts/Dashboards:** Recharts.js
    *   **Network Graphs:** Cytoscape.js
    *   **Maps:** Leaflet (via React-Leaflet)
*   **Animations & 3D:** Framer Motion (page transitions), Three.js / React Three Fiber (for 3D models)

### Initialization Command
```bash
npx create-vite vigilx-frontend --template react
cd vigilx-frontend
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
npm install react-router-dom framer-motion recharts cytoscape react-cytoscapejs leaflet react-leaflet
```

---

## 3. UI/UX & Design Philosophy

The UI must feel **highly professional, immersive, and futuristic**, reflecting a state-of-the-art military/intelligence application while maintaining excellent usability.

*   **Color Palette (Solid & Premium):**
    *   **Backgrounds:** Deep Space Charcoal (`#0D1117`), Obsidian (`#161B22`)
    *   **Accents:** Cyber Cyan (`#00F0FF`) for AI activities, Alert Red (`#FF3B30`) for high-risk targets, Neon Purple (`#BF5AF2`) for Agent visualization.
    *   **Text:** Crisp White (`#FFFFFF`) for primary, Slate Gray (`#8B949E`) for secondary.
*   **Aesthetics:**
    *   **Glassmorphism:** Use slight background blur and semi-transparent dark panels for floating menus and tooltips.
    *   **3D Models:** Integrate rotating 3D wireframe globes or abstract neural network meshes on the landing page and agent pages.
    *   **Micro-animations:** Glow effects on hover, pulse animations for active AI agents, and smooth sliding transitions for sidebars.

---

## 4. Application Architecture & Layout

The main application (post-login) follows a **Left Sidebar** layout. 

*   **Left Sidebar:** Fixed navigation, collapsible, containing icons and labels for all major modules.
*   **Top Bar:** Global search, user profile, notification bell (pulsing when AI finishes a background task).
*   **Main Content Area:** Dynamic rendering of the selected route.

### 4.1. Landing Page
*   **Visuals:** A full-screen 3D interactive particle network (representing data points connecting). 
*   **Content:** The Core Idea, bold typography ("Intelligence, Unified."), and an "Enter Secure Portal" button.
*   **Animation:** Framer motion text reveals; particle mesh reacts to mouse movement.

### 4.2. Home (Dashboard)
The central hub providing a high-level overview of the jurisdiction.
*   **Crime Analytics (Recharts.js):** 
    *   Bar charts showing crime rates by district.
    *   Line charts showing trends over the last 30 days.
*   **Criminal Network Visualization (Cytoscape.js):**
    *   A mini-graph showing the top 5 most active criminal nodes and their direct connections.
*   **Crime Hotspot Mapping (Leaflet):**
    *   A dark-themed map overlay with heatmap data showing recent incident clusters.

### 4.3. Data Studio
Where data engineers and officers connect and manage data sources.
*   **Universal Database Connector (Database Adapter Module):** **CRITICAL NOTE:** VigilX does *not* use custom default or hardcoded data connectors. We use a dynamic **Database Adapter Module** that acts as a Universal Database Connector. It dynamically loads plugins (Postgres, MongoDB, Neo4j, Excel, CSV, PDF, APIs). The frontend should render connection options dynamically based on the backend registry.
*   **Data Engineering:** Interface to trigger ETL pipelines, monitor data ingestion, and view schema mappings.
*   **DB Adapter Chatbot:** A specialized chat interface to talk *directly* to the database via the Universal Adapter (e.g., "Show me all tables related to narcotics"). 

### 4.4. AI Studio
The core interaction layer for the Multi-Agent system.
*   **Conversational AI (V1):** Standard LLM chat interface.
*   **VigilX V2 AI (Multi-Agent):** 
    *   Advanced chat interface. When processing, shows a custom node-pipeline animation instead of a generic spinner.
*   **ML Page (To be implemented):** Placeholder UI for training custom models.
*   **Agents Page:** 
    *   A visually rich directory of all 20+ internal AI agents (PlanningAgent, SQLToolAgent, etc.).
    *   Each agent card features a 3D or Lottie animation representing its purpose.
    *   Clicking an agent reveals a detailed workflow diagram of its inputs, processing logic, and outputs.

### 4.5. Experimental Studio (To be Implemented)
A sandbox for theoretical investigative modeling.
*   **Experiment:** Interface for A/B testing different prompt strategies or agent configurations.
*   **Simulations:** UI for running "what-if" crime scenarios using historical data.

### 4.6. Settings & Help Center
*   **Settings:** User preferences, API key management, theme toggles, notification settings.
*   **Help Center:** Documentation, video tutorials, and system status.

---

## 5. API Endpoints & JSON Response Formats

Below are the **EXACT** JSON templates generated directly from the live VigilX backend FastAPI OpenAPI schema. Developers must conform to these strict definitions.

### 5.1. AI Studio: V2 Chat Engine (Multi-Agent Pipeline)
**Endpoint:** `POST /ai/v2/ask`

**Request Payload (`AskRequest`):**
```json
{
  "session_id": "string",
  "user_id": "string",
  "question": "string"
}
```

**Response Payload (`InvestigationResponse` 200 OK):**
```json
{
  "response_id": "string",
  "session_id": "string",
  "user_id": "string",
  "intent": "string",
  "complexity": "simple",
  "executive_summary": "",
  "key_findings": [
    {
      "finding": "string",
      "confidence": 0.0,
      "source_agents": ["string"]
    }
  ],
  "timeline": [],
  "related_entities": [],
  "evidence_bundle": {},
  "citations": [],
  "recommendations": [
    "string"
  ],
  "chart_specs": [],
  "confidence": 0.0,
  "confidence_label": "none",
  "clarification_needed": false,
  "clarification_question": "string",
  "critic_passed": true,
  "critic_warnings": [
    "string"
  ],
  "metadata": {},
  "v2": true
}
```

### 5.2. Data Studio: Adapter Test & Connection Status
**Endpoint:** `GET /adapter-test`

**Response Payload:**
```json
{
  "status": "success",
  "message": "Adapter successfully connected and metadata synced to Postgres!",
  "detected_metadata": {},
  "registered_connectors": [
    "postgresql", 
    "csv", 
    "pdf", 
    "mongodb", 
    "neo4j", 
    "excel", 
    "json", 
    "txt", 
    "yaml", 
    "api", 
    "sqlite", 
    "mysql"
  ]
}
```
*(The frontend uses this registry to dynamically populate the Universal Database Connectors dropdown, replacing any static UI for database connections).*

### 5.3. Dashboard: Geography (Leaflet Maps)
**Endpoint:** `GET /ai/graph/geography`

### 5.4. Dashboard: Network Visualization (Cytoscape.js)
**Endpoint:** `GET /ai/graph/visualize`

*(These endpoints return the standard raw JSON for charting based on backend analysis.)*

---

## 6. Implementation Milestones

1.  **Phase 1:** Setup Vite + React + Tailwind. Implement routing, the Landing Page, and the basic Sidebar layout.
2.  **Phase 2:** Build out the Dashboard UI using the live backend endpoints for Recharts, Cytoscape, and Leaflet.
3.  **Phase 3:** Develop the Data Studio forms utilizing the Universal Database Connector.
4.  **Phase 4:** Build the AI Studio, focusing heavily on the V2 chat interface and mapping `InvestigationResponse` to the dynamic agent loading animations.
5.  **Phase 5:** Implement the Agents directory with 3D/Lottie animations.
