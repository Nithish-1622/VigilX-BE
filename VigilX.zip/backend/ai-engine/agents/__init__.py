"""LangGraph-style workflow orchestration."""
