"""Embedding pipeline modules."""
