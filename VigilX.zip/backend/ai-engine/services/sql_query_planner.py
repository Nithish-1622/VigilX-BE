from __future__ import annotations

import json
import re
from schemas.rest import RestCapability, StructuredQuery
from llm.client import LLMClient


class SQLAgentPlanner:
    """
    Structured query planning only. No direct SQL execution is allowed.
    The planner maps intent to logical REST capabilities and extracts entity filters.
    """

    def __init__(self, llm_client: LLMClient | None = None) -> None:
        self._llm_client = llm_client or LLMClient()

    async def make_plan(self, intent: str, question: str) -> StructuredQuery:
        capability = self._capability_for_intent(intent)
        filters = {}

        # 1. Regex rule-based extraction for fast, guaranteed results
        # Look for FIR number pattern (e.g. FIR-2026-101 or FIR-IN-2026-0001)
        fir_match = re.search(r'\b(FIR(?:-[A-Z]{2})?-\d{4}-\d+|FIR-\d+)\b', question, re.IGNORECASE)
        if fir_match:
            filters["fir_id"] = fir_match.group(1).upper()
            filters["fir"] = fir_match.group(1).upper()

        # Look for name patterns (e.g. "is Rajesh Kumar")
        name_match = re.search(r'\b(?:is|show|suspect|victim|for|of|about|on|name)\b\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)', question)
        if name_match:
            name_val = name_match.group(1).strip()
            # Avoid matching case, role or FIR words as name
            if not any(word in name_val.lower() for word in ["case", "fir", "robbery", "theft", "burglary", "timeline", "detail", "suspect", "victim", "accused", "person"]):
                filters["name"] = name_val

        # Look for crime type patterns — only when NOT looking up a specific FIR
        if "fir_id" not in filters:
            for crime in ["ROBBERY", "THEFT", "BURGLARY", "BANK_ROBBERY", "MURDER",
                          "ASSAULT", "KIDNAPPING", "FRAUD", "CYBERCRIME", "DRUG_TRAFFICKING"]:
                if crime.replace("_", " ").lower() in question.lower():
                    filters["crime_type"] = crime

        # 2. LLM-based entity extraction for advanced patterns
        prompt = f"""
        Extract query filters from the user question for our REST API.
        Allowed filter fields:
        - "name": Actual person's proper name (e.g. "Rajesh Kumar"). Do NOT extract generic role words.
        - "fir_id": Case reference or FIR number. E.g., "FIR-IN-2026-0001".
        - "crime_type": Type of crime ONLY if the user wants to FILTER by crime type (e.g. "show all robbery cases"). Do NOT extract crime_type if the user is ASKING about what type of crime occurred in a specific case.
        - "gender": The gender of the victim or accused (e.g. "MALE", "FEMALE").
        - "age_limit": Any age restriction mentioned (e.g. "under 18", "above 60").
        - "year": The specific year mentioned (e.g. "2025").
        - "location": Any neighborhood or district mentioned.
        - "status": The current status of the case (e.g. "UNDER_INVESTIGATION", "CLOSED").
        
        IMPORTANT RULES:
        - If the question asks "what type of crime" for a specific case, do NOT extract crime_type — return empty {{}}.
        - If a specific FIR number is mentioned, only extract fir_id.
        - Only extract filters the user explicitly wants to FILTER BY.
        - NEVER use the word "ALL" or "ANY" for a filter. If there is no specific filter, omit the key entirely.
        
        Question: "{question}"
        
        Return ONLY a raw JSON object containing these filters (empty {{}} if none found). No conversational filler or formatting blocks.
        Example: {{"name": "Rajesh Kumar", "gender": "FEMALE", "age_limit": "under 18", "year": "2025", "crime_type": "THEFT", "status": "UNDER_INVESTIGATION"}}
        """
        try:
            res = await self._llm_client.generate(prompt)
            start = res.find("{")
            end = res.rfind("}")
            if start != -1 and end != -1:
                llm_filters = json.loads(res[start:end+1])
                if isinstance(llm_filters, dict):
                    for k, v in llm_filters.items():
                        if v and str(v).strip():
                            # Don't let LLM override regex-extracted fir_id
                            if k == "fir_id":
                                if k in filters:
                                    continue
                                # Sanitize LLM hallucinations for fir_id (must contain a digit)
                                import re as _re
                                if not _re.search(r'\d', str(v)):
                                    continue

                            # Prevent LLM from hallucinating full text search filters
                            if k in {"search", "query"}:
                                continue

                            # Don't apply crime_type filter on specific FIR lookups
                            if k == "crime_type" and "fir_id" in filters:
                                continue
                            filters[k] = str(v).strip()
        except Exception:
            pass

        # Sanitize name filter to ensure no role words slipped through
        if "name" in filters and filters["name"].lower().strip() in {"suspect", "victim", "accused", "person", "complainant", "officer", "the suspect", "the victim"}:
            del filters["name"]
            
        # Sanitize crime_type filter to prevent incorrect roles from being used as crime types
        if "crime_type" in filters and filters["crime_type"].upper() in {"SUSPECT", "VICTIM", "ACCUSED", "UNKNOWN"}:
            del filters["crime_type"]
            
        # If we have extracted specific filters like name or fir_id, we shouldn't send the full question to the full-text search.
        query_text = question if not ("name" in filters or "fir_id" in filters) else ""

        return StructuredQuery(
            capability=capability,
            intent=intent,
            question=question,
            query_text=query_text,
            filters=filters,
        )

    def _capability_for_intent(self, intent: str) -> RestCapability:
        if intent == "case_lookup":
            return RestCapability.CASE_SEARCH
        if intent == "suspect_query":
            return RestCapability.CASE_SEARCH
        if intent == "victim_query":
            return RestCapability.CASE_SEARCH
        if intent == "timeline_query":
            return RestCapability.CASE_SUMMARY
        if intent == "evidence_summary":
            return RestCapability.CASE_SUMMARY
        if intent == "statistics_query":
            return RestCapability.CASE_SEARCH
        return RestCapability.CRIME_RECORDS
