"""LLM adapters and clients."""
